/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.javafxapplication1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ntu-user
 */
public class FilemanagementController {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField fileNameText;
   
    @FXML
    private TextField contentText;

    @FXML
    private Button create;
    
    @FXML
    private Button delete;
    
    @FXML
    private Button update;
    
    private void createBtnHandler(ActionEvent event) throws IOException{
        Stage primaryStage = (Stage) create.getScene().getWindow();
        try{
            File file = new File(fileNameText.getText());
            if(!file.exists()){
                file.createNewFile();
            } 
        }
        catch(FileNotFoundException e){
             e.printStackTrace();
        }
   
    }
    private void deleteBtnHandler(ActionEvent event) throws IOException{
        Stage primaryStage = (Stage) delete.getScene().getWindow();
        File file = new File(fileNameText.getText());
        if(file.exists()){
            file.delete();
        }
   
    }
    private void updateBtnHandler(ActionEvent event) throws IOException{
        Stage primaryStage = (Stage) update.getScene().getWindow();
        try{
            File file = new File(fileNameText.getText());
            if(file.exists()){
                FileWriter file2 = new FileWriter(fileNameText.getText());
                file2.write(contentText.getText());
                file2.close();
                
                public class TestFile {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the desired name of your file: ");
        String fileName = input.nextLine();
        fileName = fileName + ".txt";

        File file = new File(fileName);
    }
    
                
                
               
            } 
        }
        catch(FileNotFoundException e){
             e.printStackTrace();
        }
   
    }

    /**private static class fileText {

        private static void setText(String string) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public fileText() {
        }
    }

    private static class selectBtn {

        private static Object getScene() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public selectBtn() {
        }
    }

    private static class primaryStage {

        private static void setTitle(String select_a_File) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public primaryStage() {
        }
    }
    **/ 
    
}
