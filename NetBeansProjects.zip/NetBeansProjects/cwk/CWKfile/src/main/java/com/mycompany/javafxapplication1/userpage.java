/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javafxapplication1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 *
 * @author ntu-user
 */
//public class userpage {
//    
//    @FXML
//    private TextField fileNameText;
//   
//    @FXML
//    private TextField contextText;
//
//    @FXML
//    private Button create;
//    
//    @FXML
//    private Button delete;
//    
//    @FXML
//    private Button update;
//    
//    private void createBtnHandler(ActionEvent event) throws IOException{
//        Stage primaryStage = (Stage) create.getScene().getWindow();
//        try{
//            File file = new File(fileText.getText());
//        }
//        catch(FileNotFoundException e){
//             e.printStackTrace();
//        }
//   
//    }

    /**private static class fileText {

        private static void setText(String string) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public fileText() {
        }
    }

    private static class selectBtn {

        private static Object getScene() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public selectBtn() {
        }
    }

    private static class primaryStage {

        private static void setTitle(String select_a_File) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public primaryStage() {
        }
    }
    **/
